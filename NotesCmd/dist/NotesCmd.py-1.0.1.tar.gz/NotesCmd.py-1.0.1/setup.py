from distutils.core import setup
setup(name='NotesCmd.py',
	version='1.0.1',
	description='Simple Commandline notes',
	author='Demagog',
	author_email='johndoe@example.com',
	url='https://github.com/Demagogue/gSimpleNotes.git',
	py_modules=['NotesCmd.py',],)
	
